<%
response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");

if (session.getAttribute("admin") == null) {
    response.sendRedirect("login.jsp");
    return;
}
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Return Book</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="page-card">
    <h2>Return Book</h2>

    <form action="ReturnBookServlet" method="post">
        <div class="form-row">
            <label>Issue ID</label>
            <input type="number" name="issueId" required>
        </div>

        <div class="form-row">
            <label>Book ID</label>
            <input type="number" name="bookId" required>
        </div>

        <input type="submit" value="Return Book">
    </form>

    <a class="back-link" href="dashboard.jsp">Back to Dashboard</a>
</div>

</body>
</html>