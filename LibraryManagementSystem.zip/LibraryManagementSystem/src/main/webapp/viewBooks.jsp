<%
response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");

if (session.getAttribute("admin") == null) {
    response.sendRedirect("login.jsp");
    return;
}
%>
<%@ page import="java.util.*, com.library.dao.BookDAO, com.library.model.Book" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>View Books</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="table-container">
    <h2>All Books</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Category</th>
            <th>Quantity</th>
            <th>Actions</th>
        </tr>

        <%
            BookDAO dao = new BookDAO();
            List<Book> list = dao.getAllBooks();

            for (Book b : list) {
        %>
        <tr>
            <td><%= b.getBookId() %></td>
            <td><%= b.getTitle() %></td>
            <td><%= b.getAuthor() %></td>
            <td><%= b.getCategory() %></td>
            <td><%= b.getQuantity() %></td>
            <td>
                <a class="action-link edit-btn" href="editBook.jsp?id=<%= b.getBookId() %>">Edit</a>
                <a class="action-link delete-btn" href="DeleteBookServlet?id=<%= b.getBookId() %>">Delete</a>
            </td>
        </tr>
        <%
            }
        %>
    </table>

    <a class="back-link" href="dashboard.jsp">Back to Dashboard</a>
</div>

</body>
</html>