<%
response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");

if (session.getAttribute("admin") == null) {
    response.sendRedirect("login.jsp");
    return;
}
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Dashboard</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="dashboard-links">
    <h2>Library Dashboard</h2>
    <a href="addBook.jsp">Add Book</a>
    <a href="viewBooks.jsp">View Books</a>
    <a href="issueBook.jsp">Issue Book</a>
    <a href="returnBook.jsp">Return Book</a>
    <a href="viewIssuedBooks.jsp">Issued Books</a>
    <a href="LogoutServlet">Logout</a>
</div>

</body>
</html>