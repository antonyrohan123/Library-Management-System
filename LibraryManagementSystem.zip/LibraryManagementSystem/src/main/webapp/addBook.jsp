<%
response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");

if (session.getAttribute("admin") == null) {
    response.sendRedirect("login.jsp");
    return;
}
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add Book</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="page-card">
    <h2>Add Book</h2>

    <form action="AddBookServlet" method="post">
        <div class="form-row">
            <label>Title</label>
            <input type="text" name="title" required>
        </div>

        <div class="form-row">
            <label>Author</label>
            <input type="text" name="author" required>
        </div>

        <div class="form-row">
            <label>Category</label>
            <input type="text" name="category" required>
        </div>

        <div class="form-row">
            <label>Quantity</label>
            <input type="number" name="quantity" required>
        </div>

        <input type="submit" value="Add Book">
    </form>

    <a class="back-link" href="dashboard.jsp">Back to Dashboard</a>
</div>

</body>
</html>