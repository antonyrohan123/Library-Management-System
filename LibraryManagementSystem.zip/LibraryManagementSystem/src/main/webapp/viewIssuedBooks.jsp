<%@ page import="java.sql.*, com.library.util.DBConnection" %>
<%
response.setContentType("text/html; charset=UTF-8");

if (session.getAttribute("admin") == null) {
    response.sendRedirect("login.jsp");
    return;
}
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Issued Books</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="table-container">
    <h2>Issued Books</h2>

    <table>
        <tr>
            <th>Issue ID</th>
            <th>Book ID</th>
            <th>Student ID</th>
            <th>Issue Date</th>
            <th>Return Date</th>
            <th>Status</th>
            <th>Fine</th>
        </tr>

        <%
            Connection con = null;
            PreparedStatement ps = null;
            ResultSet rs = null;

            try {
                con = DBConnection.getConnection();

                if (con == null) {
        %>
                    <tr>
                        <td colspan="7">Database connection failed</td>
                    </tr>
        <%
                } else {
                    String sql = "SELECT issue_id, book_id, student_id, issue_date, return_date, status, " +
                                 "CASE " +
                                 "WHEN status='Issued' AND CURDATE() > return_date THEN DATEDIFF(CURDATE(), return_date) * 5 " +
                                 "ELSE 0 " +
                                 "END AS fine " +
                                 "FROM issued_books ORDER BY issue_id DESC";

                    ps = con.prepareStatement(sql);
                    rs = ps.executeQuery();

                    boolean hasData = false;

                    while (rs.next()) {
                        hasData = true;
        %>
        <tr>
            <td><%= rs.getInt("issue_id") %></td>
            <td><%= rs.getInt("book_id") %></td>
            <td><%= rs.getInt("student_id") %></td>
            <td><%= rs.getDate("issue_date") %></td>
            <td><%= rs.getDate("return_date") %></td>
            <td><%= rs.getString("status") %></td>
            <td>₹ <%= rs.getInt("fine") %></td>
        </tr>
        <%
                    }

                    if (!hasData) {
        %>
        <tr>
            <td colspan="7">No issued books found</td>
        </tr>
        <%
                    }
                }
            } catch (Exception e) {
        %>
        <tr>
            <td colspan="7">Error: <%= e.getMessage() %></td>
        </tr>
        <%
                e.printStackTrace();
            } finally {
                try { if (rs != null) rs.close(); } catch (Exception e) {}
                try { if (ps != null) ps.close(); } catch (Exception e) {}
                try { if (con != null) con.close(); } catch (Exception e) {}
            }
        %>
    </table>

    <a class="back-link" href="dashboard.jsp">Back to Dashboard</a>
</div>

</body>
</html>