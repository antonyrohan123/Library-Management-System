<%
response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");

if (session.getAttribute("admin") == null) {
    response.sendRedirect("login.jsp");
    return;
}
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Issue Book</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="page-card">
    <h2>Issue Book</h2>

    <form action="IssueBookServlet" method="post">
        <div class="form-row">
            <label>Book ID</label>
            <input type="number" name="bookId" required>
        </div>

        <div class="form-row">
            <label>Student ID</label>
            <input type="number" name="studentId" required>
        </div>

        <div class="form-row">
            <label>Issue Date</label>
            <input type="date" name="issueDate" required>
        </div>

        <div class="form-row">
            <label>Return Date</label>
            <input type="date" name="returnDate" required>
        </div>

        <input type="submit" value="Issue Book">
    </form>

    <a class="back-link" href="dashboard.jsp">Back to Dashboard</a>
</div>

</body>
</html>