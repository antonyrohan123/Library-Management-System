package com.library.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.library.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/IssueBookServlet")
public class IssueBookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int bookId = Integer.parseInt(request.getParameter("bookId"));
        int studentId = Integer.parseInt(request.getParameter("studentId"));
        String issueDate = request.getParameter("issueDate");
        String returnDate = request.getParameter("returnDate");

        try {
            Connection con = DBConnection.getConnection();

            if (con == null) {
                response.getWriter().println("Database connection failed");
                return;
            }

            String checkBookSql = "SELECT quantity FROM books WHERE book_id = ?";
            PreparedStatement checkPs = con.prepareStatement(checkBookSql);
            checkPs.setInt(1, bookId);
            ResultSet rs = checkPs.executeQuery();

            if (rs.next()) {
                int quantity = rs.getInt("quantity");

                if (quantity > 0) {
                    String insertSql = "INSERT INTO issued_books(book_id, student_id, issue_date, return_date, status) VALUES (?, ?, ?, ?, ?)";
                    PreparedStatement insertPs = con.prepareStatement(insertSql);
                    insertPs.setInt(1, bookId);
                    insertPs.setInt(2, studentId);
                    insertPs.setString(3, issueDate);
                    insertPs.setString(4, returnDate);
                    insertPs.setString(5, "Issued");

                    int rows = insertPs.executeUpdate();

                    if (rows > 0) {
                        String updateBookSql = "UPDATE books SET quantity = quantity - 1 WHERE book_id = ?";
                        PreparedStatement updatePs = con.prepareStatement(updateBookSql);
                        updatePs.setInt(1, bookId);
                        updatePs.executeUpdate();
                        updatePs.close();

                        response.sendRedirect("viewIssuedBooks.jsp");
                    } else {
                        response.getWriter().println("Book issue failed");
                    }

                    insertPs.close();
                } else {
                    response.getWriter().println("Book not available");
                }
            } else {
                response.getWriter().println("Book ID not found");
            }

            rs.close();
            checkPs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}