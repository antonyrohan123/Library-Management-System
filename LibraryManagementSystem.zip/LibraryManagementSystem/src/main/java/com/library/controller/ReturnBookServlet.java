package com.library.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.library.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ReturnBookServlet")
public class ReturnBookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int issueId = Integer.parseInt(request.getParameter("issueId"));
        int bookId = Integer.parseInt(request.getParameter("bookId"));

        try {
            Connection con = DBConnection.getConnection();

            if (con == null) {
                response.getWriter().println("Database connection failed");
                return;
            }

            String checkSql = "SELECT status FROM issued_books WHERE issue_id = ?";
            PreparedStatement checkPs = con.prepareStatement(checkSql);
            checkPs.setInt(1, issueId);
            ResultSet rs = checkPs.executeQuery();

            if (rs.next()) {
                String status = rs.getString("status");

                if ("Returned".equalsIgnoreCase(status)) {
                    response.getWriter().println("This book is already returned");
                } else {
                    String updateIssueSql = "UPDATE issued_books SET status = 'Returned' WHERE issue_id = ?";
                    PreparedStatement updateIssuePs = con.prepareStatement(updateIssueSql);
                    updateIssuePs.setInt(1, issueId);

                    int rows = updateIssuePs.executeUpdate();

                    if (rows > 0) {
                        String updateBookSql = "UPDATE books SET quantity = quantity + 1 WHERE book_id = ?";
                        PreparedStatement updateBookPs = con.prepareStatement(updateBookSql);
                        updateBookPs.setInt(1, bookId);
                        updateBookPs.executeUpdate();

                        updateBookPs.close();
                        response.sendRedirect("viewIssuedBooks.jsp");
                    } else {
                        response.getWriter().println("Return failed");
                    }

                    updateIssuePs.close();
                }
            } else {
                response.getWriter().println("Issue ID not found");
            }

            rs.close();
            checkPs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}